package animais;

import javax.swing.JOptionPane;

public class Animal {
  public static void main(String[] args) {
    String nome = null;
    int resposta;
    int pensou;
    String animal = null;
    
    nome = JOptionPane.showInputDialog("pense em um animal");
    resposta = JOptionPane.showConfirmDialog(null, "pensou em um animal ?");
    
    animal = JOptionPane.showInputDialog("pense em um animal");
    pensou = JOptionPane.showConfirmDialog(null, "pensou em um animal ?");
    
    /*
    if ( == JOptionPane.YES_OPTION) {
        JOptionPane.showMessageDialog(null, "acertei o animal " + );
      } else {
        JOptionPane.showMessageDialog(null, "não acertei" + );
      }*/
    
    
    if (pensou == JOptionPane.NO_OPTION) {
        JOptionPane.showMessageDialog(null, "não pensou");
      } else if (pensou == JOptionPane.YES_OPTION) {
    	  JOptionPane.showMessageDialog(null, "acertei o animal " + nome);
      } else {
    	  JOptionPane.showMessageDialog(null, "não acertei" + nome);
        } 
    
  }
}
